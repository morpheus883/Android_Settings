
      ===========########
     ======  Amiko A5  ####
    ====== HD Settings #####
     == � by Morpheus883 ##
      ===========########

Morpheus883's Site: http://morpheus883.altervista.org/
GitHub Repository: https://github.com/morpheus883/
and available on the main Sat Sites

Amiko A5 Settings 3rd June 2020, � by Morpheus883

Settings for Images based on Android FW's:

Statistics:
# Clarke Belt covered: 47.5�W - 76.5�E
# Satellites: 89 (Ku Band TP)
# Ordered Provider Lists: 44
# Services: 18.386

 [30.0 W]   Meo
 [30.0 W]   Nos
 [5.0 W]   Bis / Orange / Fransat
 [4.0 W]   Magio TV
 [0.8 W]   Canal Digital Nordic
 [0.8 W]   Focus Sat
 [0.8 W]   RCS DigiTV
 [0.8 W]   UPC Direct
 [1.9 E]   Polaris Media
 [4.8 E]   Viasat
 [4.8 E]   VisionTV
 [7.0 E]   Digit�rk
 [9.0 E]   Joyne
 [9.0 E]   Kabelkiosk
 [9.0 E]   OTE
 [13.0 E]   BIS/Orange FR
 [13.0 E]   Cyfrowy Polsat
 [13.0 E]   NC+/Orange PL
 [13.0 E]   Nova
 [13.0 E]   RAI/Mediaset/Tiv�Sat
 [13.0 E]   Sky Italia
 [16.0 E]   Digit Alb
 [16.0 E]   Max TV
 [16.0 E]   Total TV
 [19.2 E]   CanalSat
 [19.2 E]   Orange FR
 [19.2 E]   Movistar+
 [19.2 E]   HD +/Sky D/ARD
 [19.2 E]   Canal Digitaal/TV Vlaanderen
 [23.5 E]   Canal Digitaal/TV Vlaanderen
 [23.5 E]   CS Link/SkyLink
 [28.2 E]   BBC
 [28.2 E]   Freesat
 [28.2 E]   Sky Digital
 [31.5 E]   MagtiSat
 [31.5 E]   Orange Romania
 [39.0 E]   Bulsatcom
 [39.0 E]   Dolce TV
 [42.0 E]   D-Smart
 [42.0 E]   Digit�rk
 [42.0 E]   Filbox
 [42.0 E]   Tivibu (East Beam)
 [42.0 E]   T�rksat
 [45.0 E]   Vivacom/NURTS

=== Compiled with Morpheus883's scripts ===
 ======== � by Morpheus883, 2020 ========
 

You can find everything and much more on:
Morpheus883's Site: http://morpheus883.altervista.org/
GitHub Repository: https://github.com/morpheus883/